import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();

        int[] ida = {60, 60, 120, 70, 120, 100, 90, 80, 70, 100};
        int[] volta = {80, 90, 60, 100, 100, 60, 60, 120, 100, 120};
        //int[] ida = new int[10];
        //int[] volta = new int[10];
        int contConsect = 0, limite = 80, multa = 0;

        System.out.print("Ida: ");
        for (int i = 0; i < ida.length; i++) {
            //ida[i] = random.nextInt(60, 141);
            System.out.print(ida[i] + " ");

            if (i > 0 && ida[i] == ida[i - 1]) {
                contConsect++;
            }

            if (ida[i] > limite) {
                double limiteAte20 = limite * 1.2;

                if (ida[i] <= limiteAte20) {
                    multa += 100;
                } else {
                    multa += 300;
                }
            }
        }

        System.out.print("\nVolta: ");
        for (int i = 0; i < volta.length; i++) {
            //volta[i] = random.nextInt(60, 141);
            System.out.print(volta[i] + " ");
        }

        int contVolta = 0;
        for (int i = ida.length - 1; i >= 0; i--) {
            if (ida[i] == volta[contVolta]) {
                System.out.printf("\nPosição: %d", i + 1);
            }
            contVolta++;
        }


        System.out.println("\nQuantidade de vezes que apareceu uma velocidade consecutiva: " + contConsect);
        System.out.println("A multa na ida: " + multa);
    }
}